
str1 = input("Enter a string")
a1 = "a,e,i,o,u,A,E,I,O,U"
v = 0
c = 0
for i in str1:
    if i in a1:
        v= v+1
        print("vowels",v)

    else:
        c= c+1
print("consonant",c)
