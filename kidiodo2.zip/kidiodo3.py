arr = [1,2,3,4,5]
add = sum(arr)
div = len(arr)
avg = add/div
for i in arr:
    if i>avg:
        print(avg)
