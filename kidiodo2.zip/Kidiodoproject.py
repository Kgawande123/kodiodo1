
## custom exception
class MarksExceptionError(BaseException):
    def __init__(self,msg):
       self.msg = msg
marks = int(input("Enter a marks:"))
if marks >100 or marks<0 :
    raise MarksExceptionError(" marks must be 0 to 100")
else:
    print("Yo got",marks)

